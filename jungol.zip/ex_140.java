package jungol;
import java.util.Scanner;

public class ex_140 {

	public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			int num;
			int sum = 0, count = 0;
			for(int i = 0; i < 20; i++) {
				num = input.nextInt();
				if(num > 0) {
					sum += num;
					count++;
				}
				if(num == 0) {break;}
			}
			System.out.printf("%d %d", sum,sum/count);
		}
	}

