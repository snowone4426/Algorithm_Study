package jungol;
import java.util.Scanner;

public class ex_141 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int n1 = 1;
		int n2 = 1;
		if(n >= 1 && n <= 100) {
			while(true) {
				if(n1 % 10 == 0) {
					break;
				}
				n1 = n * n2;
				if(n1 >= 100) {
					break;
				}else {
					System.out.print(n1 + " ");
				}
				n2++;
				}
			}
		}
	}
	
