package jungol;
import java.util.Scanner;
public class ex_142 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		for(int i = 1; i <= num; i++) {
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.print("\n");
		}
		for(int i = 1; i <= num; i++) {
			for(int k = 1; k <= num - i; k++) {
				System.out.print("*");
			}
			System.out.print("\n");
		}
	}
}
