package jungol;
import java.util.Scanner;
public class ex_143 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < i; j++) {
				System.out.print(" ");
			}
			for(int j = 0; j < (n*2) - (i+i+1); j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		int cnt = 1;
		int downNum = 0;
		for(int i = 0; i < n-1; i++) {
			for(int j = n ; j > 1+cnt; j--) {
				System.out.print(" ");
			}
			cnt++;
			for(int j = 0; j < 3 + downNum; j++) {
				System.out.print("*");
			}
			downNum += 2;
			System.out.println();
		}
	}
}
	
