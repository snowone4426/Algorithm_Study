package jungol;
import java.util.Scanner;
public class ex_144 {	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		for(int i = 0; i < n; i++) {
			for(int j = 1; j < (n-i)*2-1; j++) {
				System.out.printf(" ");
			}
			for(int j = 0; j < i*2+1; j++) {
				System.out.printf("*");
			}
			System.out.printf("\n");
		}
	}	
}
	