package jungol;
import java.util.Scanner;
public class ex_146 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		char ch = 'A';
		int num = 0; 
		if(n <= 6) {			
			for(int i = 0; i < n; i++) {
				for(int j = 0; j < (n-i); j++) {
					System.out.printf("%c ",ch++);
				}
				for(int j = 0; j < i; j++) {
					System.out.printf("%d ",num++);
				}
				System.out.printf("\n");
			}
		}
	}
}

