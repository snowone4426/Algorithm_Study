package jungol;
import java.util.Scanner;
public class ex_147 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int count = 1;
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < i; j++) {
				System.out.printf("  ");
			}
			for(int k = 0; k < n-i; k++) {
				System.out.printf("%d ",count);
				count++;
			}
			System.out.printf("\n");
		}
	}
}
