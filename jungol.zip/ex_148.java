package jungol;
import java.util.Scanner;
public class ex_148 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		for(int i = 0; i < n; i++) {
			for(int j = 0; j <= i; j++) {
				System.out.printf("%s ","#");
			}
			System.out.printf("\n");
		}
		for(int i = 0; i < n - 1; i++) {			
			for(int k = 0; k <= i; k++) {
				System.out.printf("  ");
			}
			for(int l = 1; l < n - i; l++) {
				System.out.printf("%s ","#");
			}
			System.out.printf("\n");
		}
	}
}

