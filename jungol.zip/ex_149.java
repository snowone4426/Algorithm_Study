package jungol;
import java.util.Scanner;
public class ex_149 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int odd = 1;
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				if(odd >= 10) odd = 1;
				System.out.printf("%d ",odd);
				odd += 2;
			} 
			System.out.printf("\n");
		}
	}
}