package jungol;
import java.util.Scanner;

public class ex_150 {
	static String toString(char[] arr) {
		String ch = "";
		for(int i = arr.length-1; i >= 0; i--) {
			ch += arr[i] + " ";
		}
		return ch;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		char[] arr = new char[10];
		for(int i = 0; i < arr.length; i++)
		{
			arr[i] = input.next().charAt(0);
		}
		
		System.out.println(toString(arr));
	}
}

