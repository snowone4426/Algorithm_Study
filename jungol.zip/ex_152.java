package jungol;
import java.util.Scanner;

public class ex_152 {
Scanner input = new Scanner(System.in);
//int[] arr = new int[10];
//int odd = 0;
//int even = 0;
//
//	for (int i = 0; i < 10; i++) {
//		arr[i] = input.nextInt();
//}
//	for (int j = 0; j < 10; j++) {
//		if (j % 2 == 0) {
//			odd += arr[j];
//		}else {
//		even += arr[j];
//	}
//}
//
//System.out.println("odd : " + odd);
//
//System.out.println("even : " + even);
//}
}

