package jungol;
import java.util.Scanner;

public class ex_153 {
Scanner input = new Scanner(System.in);
//int[] arr = new int[100];
//
//for (int i=0;)
}
