package jungol;
import java.util.Scanner;

public class ex_154 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double [] arr = new double[6];
		int size = arr.length;
		double count = 0;
		double sum = 0;
		double avg = 0;
		
		for (int i=0;i<size;i++) {
			arr[i] = input.nextDouble();
			count++;
			sum += arr[i];
		}
		avg = sum/count;
		System.out.printf("%.1f", avg);
	}
}
