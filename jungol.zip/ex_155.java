package jungol;
import java.util.Scanner;

public class ex_155 {
	private static final int MAX = 6;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		char[] arr = new char[MAX];
		arr[0] = 'J';
		arr[1] = 'U';
		arr[2] = 'N';
		arr[3] = 'G';
		arr[4] = 'O';
		arr[5] = 'L';
		
		char ch = input.nextLine().charAt(0);
		int count = 0;
		for(int i = 0; i < MAX; i++) {
			if(arr[i] == ch) {
				System.out.println(i);
				count++;
			}
		}

		if(count == 0) {
			System.out.println("none");
		}
		
	}
}

