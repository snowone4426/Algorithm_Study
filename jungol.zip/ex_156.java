package jungol;
import java.util.Scanner;

public class ex_156 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] arr = new int[100];
		
		int cnt = 1;
		for(int i = 0; i < 100; i++) {
			int num = input.nextInt();
			if(num == 999) break;
			arr[i] = num;
			cnt++;
		}
		
		int max = arr[0];
		int min = arr[0];
		for(int i = 1; i < cnt-1; i++) {
			if(arr[i] > max) {
				max = arr[i];
			}
			
			if(arr[i] < min) {
				min = arr[i];
			}
		}
		
		System.out.println("max : "+ max);
		System.out.println("min : "+ min);
	}
}

