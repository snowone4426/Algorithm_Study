package jungol;
import java.util.Scanner;

public class ex_157	{
public static void main(String args[]) {

	Scanner input = new Scanner(System.in);

	int[] arr = new int[100];

	int sum = 0;

	double average=0;

	int save=0;

	int count=0;

	for (int i = 0; i < arr.length; i++) {

		arr[i] = input.nextInt();

		if (arr[i] == 0) {
			save = i;
			break;
			}
		}
	for (int i = 0; i < save; i++) {
		if(arr[i] % 5 == 0) {
			count++;
			sum += arr[i];
			}
		}
average = (double)sum/count;
System.out.println("Multiples of 5 : "+ count);
System.out.println("sum : " + sum);
System.out.printf("avg : %.1f", average);

	}

}


