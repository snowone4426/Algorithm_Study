package jungol;
import java.util.Scanner;

public class ex_160 {

}

