package jungol;
import java.util.Scanner;

public class ex_162 {
	final static int MAX = 10; 
	static String toString(int[] basic) {
		String makeString = "";
		for(int one : basic) {
			makeString += one + " ";
		}
		return makeString;
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int input1 = input.nextInt();
		int input2 = input.nextInt();
		int[] basic = new int[MAX];
		basic[0] = input1;
		basic[1] = input2;
		for(int i = 2; i < MAX; i++) {
			int num = basic[i-2] + basic[i-1];
			basic[i] = num % 10;
		}
		System.out.println(toString(basic));
	}
}
