package jungol;
import java.util.Scanner;

public class ex_163 {
	final static int ROW = 4; 
	final static int COLUMN = 3; 
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[][] basic = new int[ROW][COLUMN];
		basic[0][0] = 3;
		basic[0][1] = 5;
		basic[0][2] = 9;
		basic[1][0] = 2;
		basic[1][1] = 11;
		basic[1][2] = 5;
		basic[2][0] = 8;
		basic[2][1] = 30;
		basic[2][2] = 10;
		basic[3][0] = 22;
		basic[3][1] = 5;
		basic[3][2] = 1;
		
		int total = 0;
		for(int[] oneArr : basic) {
			for(int one : oneArr) {
				System.out.print(one + " ");
				total += one;
			}
			System.out.println();
		}
		
		System.out.println(total);
	}
}
