package jungol;
import java.util.Scanner;

public class ex_168 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int max = input.nextInt();
		int[][] basic = new int[max][max];
		for(int i = 0; i < max; i++) {
			for(int j = 0; j < i+1; j++) {
				if(j == 0)	basic[i][j] = 1;
				else if(i == j) basic[i][j] = 1;
				else basic[i][j] = basic[i-1][j-1] + basic[i-1][j];
			}
		}
	}
}
