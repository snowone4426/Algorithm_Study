package jungol;
import java.util.Scanner;

public class ex_169 {
	static int[] row = new int[3];
	private static int coulmn;
	int[] column = new int[5];
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char[][] basic = new char[row][coulmn];
		char[][] small = new char[row][coulmn];
		for(int i = 0; i < row; i++) {
			for(int j = 0; j < coulmn; j++) {
				basic[i][j] = sc.next().charAt(0);
				small[i][j] = (char) (basic[i][j] + 32);
			}
		}
		
		for(char[] oneArr : small) {
			for(char one : oneArr) {
				System.out.print(one + " ");
			}
			System.out.println();
		}
		
		
	}
}

