package jungol;

import java.util.Scanner;
public class ex_549 {

	public static void main(String[] args) {
		 Scanner input = new Scanner(System.in);
		 
		 int n = input.nextInt();
		 int sum = 0;
		 int i;
		 
		 for(i = 1; sum < n; i += 2) {
			 if( i % 2 != 0) {
				 sum += i;
			 }
		 }
		 System.out.println(i/2 + " " + sum);
	}
}