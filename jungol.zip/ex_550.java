package jungol;

import java.util.Scanner;
public class ex_550{

	public static void main(String[] args) {
		 Scanner input = new Scanner(System.in);
		 
		 int n = input.nextInt();
		 
		 for(int i = 0; i <= n; i++) {
			 for(int j = n; j > i; j--) {
				 System.out.print("*");
			 }System.out.println("");
		 }		 
		 for(int i = 0; i <= n; i++) {
			 for(int j = 0; j < i; j++) {
				 System.out.print("*");
			 }System.out.println("");
		 }
		 
	}
}

