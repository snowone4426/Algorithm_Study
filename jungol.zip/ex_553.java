package jungol;
import java.util.*;
public class ex_553 {
 public static void main(String[] args) {    
  int n;
  char tmp='A';
     Scanner input = new Scanner(System.in);
     n = input.nextInt();
     for(int i=0;i<n;i++){
         for(int j=1;j<=n-i;j++){
          System.out.printf("%c", tmp);
          tmp++;
         }
         System.out.printf("\n");
     }
 }
}
