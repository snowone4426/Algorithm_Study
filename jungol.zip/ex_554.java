package jungol;
import java.util.*;
public class ex_554 {
public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	int num = input.nextInt();
	int increNum = 1;
	char increChar = 'A';
		for(int i = 0; i < num; i ++) {
			for(int j = 0; j < num-i; j++) {
				System.out.print(increNum+ " ");
				increNum++;
			}
			for(int j = 0; j < i+1; j++) {
				System.out.print(increChar + " ");
				increChar++;
			}
			System.out.println();
		}
	}
}
