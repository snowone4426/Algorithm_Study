package jungol;
import java.util.Scanner;
public class ex_555 {
	public static void main(String[] args) {
//		String str;
//		Scanner input = new Scanner(System.in);
//		char[] arr = new char[10];
////		nextLine()는 Enter를 치기 전까지 쓴 문자열을 모두 리턴
////		next()는 스페이스 즉 공백 전까지 입력받은 문자열을 리턴
//
//		for(int i = 0;i < arr.length; i++) {
//			String arr = input.nex
//		}
//	
//	}
     int i;
     String a;
     Scanner input = new Scanner(System.in);
     String n = input.nextLine();
     for(i=0;i<20;i+=2) {
      System.out.printf("%c", n.charAt(i));
     }
 }
}

