package jungol;
import java.util.*;
public class ex_557 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String ch = input.nextLine();
		String[] ch_arr = ch.split(" ");
		System.out.print(ch_arr[0] + " " + ch_arr[3] + " " + ch_arr[6]);
	}
}
