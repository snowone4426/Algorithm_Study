package jungol;
import java.util.Scanner;
public class ex_558 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] arr = new int[100];
		int start = 0;
		
		for(int i = 0; i < 100; i++) {
			arr[i] = input.nextInt();
			
			if(arr[i] == 0) {
				start = i-1;
				break;
			}
		}
		for(int i = start; 0 <= i; i--) {
			System.out.print(arr[i] + " ");
		}
	}
}

