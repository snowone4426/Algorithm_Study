package jungol;
import java.util.Scanner;
public class ex_559 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double[] avg = {85.6, 79.5, 83.1, 80.0, 78.2, 75.0};
		int avg1 = input.nextInt();
		int avg2 = input.nextInt();
		double total = avg[avg1-1] + avg[avg2-1]; 
		System.out.printf("%.1f",total);
	}
}
