package jungol;
import java.util.Scanner;
public class ex_561 {
public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	int[] intArr = new int[10];
	int max = 0; int min = 10000;
		
	for(int i = 0; i < intArr.length; i++)
	{
		intArr[i] = input.nextInt();
		if(0 < i) {
			if(intArr[i] >= 100)
				min = min < intArr[i] ? min : intArr[i];
			else if(intArr[i] < 100)
				max = intArr[i] > max ? intArr[i] : max;
		}else if(i==0) {
			if(intArr[i] < 100) {
				max = intArr[i];
			}else
				min = intArr[i];
		}
	}
	if(max == 0)
		max = 100;
	if(min == 10000)
		min = 100;
	System.out.println(max+" "+min);
	}
}

