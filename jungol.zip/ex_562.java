package jungol;
import java.util.ArrayList;
import java.util.Scanner;

public class ex_562 {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] arr = new int[10];
		int evenSum = 0;
		int oddSum = 0;
		int oddCount = 0;
		for(int i = 0; i < arr.length; i++)
		{
			arr[i] = input.nextInt();
			
			if(i == 0) {
				oddSum += arr[i];
				oddCount++;
			}else if(i % 2 != 0){
				evenSum += arr[i];
			}else{
				oddSum += arr[i];
				oddCount++;
			}
			
		}
		
		double avg = oddSum / (double)oddCount;
		
		System.out.printf("sum : %d\n", evenSum);
		System.out.printf("avg : %.1f", avg);
	}
}

