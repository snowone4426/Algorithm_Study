package jungol;
import java.util.Scanner;

public class ex_563 {
	static String toString(int[] arr) {
		String ch = "";
		for(int one : arr) {
			ch += one + " ";
		}
		return ch;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int[] arr = new int[10];
		int blank = 0;
		for(int i = 0; i < arr.length; i++)
		{
			arr[i] = input.nextInt();
		}
		
		for(int i = 0; i < arr.length-1; i++) {
			for(int j = i+1; j < arr.length; j++) {
				if(arr[i] < arr[j]) {
					blank = arr[i];
					arr[i] = arr[j];
					arr[j] = blank;
				}
			}
		}
		
		System.out.println(toString(arr));
	}
}

