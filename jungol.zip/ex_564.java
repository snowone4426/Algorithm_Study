package jungol;
import java.util.Scanner;

public class ex_564 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		char[] arr = new char[100];
		int[] max = new int[100];
		int[] min = new int[2];
		
//		for(int i = 0; i < max; i++) {
//			char n = input.next().charAt(0);
//			if(n < 65 || n >= 91) {
//				break;
//			}
//			arr[i] = n;
//		}

	}
}
