package jungol;
import java.util.Scanner;

public class ex_566 {
	static String toString(int[] intArr, int cnt) {
		int[] max = new int[100];
		String makeString = "";
		for(int i = 0; i < cnt; i++) {
			makeString += intArr[i] + " ";
		}
		return makeString;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
//		int[] arr = new int[max];
//		arr[0] = 100;
//		arr[1] = num;
//		int cnt = 2;
//		for(int i = 2; i < arr.length; i++) {
//			arr[i] = arr[i-2] - arr[i-1];
//			cnt++;
//			if(arr[i] < 0) {
//				break;
//			}
		}
		
//		System.out.println(toString(arr, cnt));
		
	}
//}
