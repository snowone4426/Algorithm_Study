package jungol;
public class ex_567 {
	public static void main(String[] args) {
		int[][] intArr = new int[3][5];
		intArr[0][0] = 5;
		intArr[0][1] = 8;
		intArr[0][2] = 10;
		intArr[0][3] = 6;
		intArr[0][4] = 4;
		intArr[1][0] = 11;
		intArr[1][1] = 20;
		intArr[1][2] = 1;
		intArr[1][3] = 13;
		intArr[1][4] = 2;
		intArr[2][0] = 7;
		intArr[2][1] = 9;
		intArr[2][2] = 14;
		intArr[2][3] = 22;
		intArr[2][4] = 3;
		
		for(int[] oneArr : intArr) {
			for(int one : oneArr) {
				System.out.printf("%2d   ", one);
			}
			System.out.println();
		}
	}
}
