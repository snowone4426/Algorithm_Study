package jungol;
import java.util.Scanner;

public class ex_569 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[][] score = new int[5][4];
        float sum = 0;
        float average = 0;
        int cnt = 0;

        float[] average1 = new float[5];

        for(int i = 0; i < score.length; i++) {
            for(int j = 0; j < score[i].length; j++) {
                score[i][j] = input.nextInt();
            }
        }

        for(int i = 0; i < score.length; i++) {
            for(int j = 0; j < score[i].length; j++) {
                sum += (float)score[i][j];
                average = sum / 4;

            }
            average1[i] = average;
            sum = 0;
        }

        for(int i = 0; i < 5; i++) {
            if(average1[i] >= 80) {
                System.out.println("pass");
                cnt++;
            } else {
                System.out.println("fail");
            }
        }
        System.out.print("Successful" + " : " + cnt);
    }
}
