package jungol;
import java.util.Scanner;
public class ex_634 {

	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	int n = input.nextInt();
	for(int i=1;i<=n;i++) {
		for(int j=i;j<=n;j++) {
			System.out.print("*");
		}
		System.out.println();
	}
	}

}
